from machine import Pin, I2C
import time
import framebuf

# =====================================================
# SSD1306 driver (inline) — works in MicroPython on ESP32
# =====================================================
class SSD1306:
    def __init__(self, width, height, external_vcc):
        self.width = width
        self.height = height
        self.external_vcc = external_vcc
        self.pages = self.height // 8
        self.buffer = bytearray(self.width * self.pages)
        self.fb = framebuf.FrameBuffer(self.buffer, self.width, self.height, framebuf.MONO_VLSB)
        self.init_display()

    def init_display(self):
        for cmd in (
            0xAE,       # DISPLAYOFF
            0x20, 0x00, # MEMORYMODE horizontal
            0x40,       # SETSTARTLINE
            0xA1,       # SEGREMAP
            0xC8,       # COMSCANDEC
            0xDA, 0x12, # SETCOMPINS
            0x81, 0xCF, # SETCONTRAST
            0xA4,       # DISPLAYALLON_RESUME
            0xA6,       # NORMALDISPLAY
            0xD5, 0x80, # SETDISPLAYCLOCKDIV
            0x8D, 0x14, # CHARGEPUMP
            0xAF        # DISPLAYON
        ):
            self.write_cmd(cmd)
        self.fill(0)
        self.show()

    def write_cmd(self, cmd):
        raise NotImplementedError

    def write_data(self, buf):
        raise NotImplementedError

    def show(self):
        for page in range(self.pages):
            self.write_cmd(0xB0 + page)  # PAGEADDR
            self.write_cmd(0x00)         # low col
            self.write_cmd(0x10)         # high col
            start = self.width * page
            self.write_data(self.buffer[start:start + self.width])

    def fill(self, col):
        self.fb.fill(col)

    def text(self, s, x, y, col=1):
        self.fb.text(s, x, y, col)

class SSD1306_I2C(SSD1306):
    def __init__(self, width, height, i2c, addr=0x3C, external_vcc=False):
        self.i2c = i2c
        self.addr = addr
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.i2c.writeto(self.addr, bytearray([0x00, cmd]))

    def write_data(self, buf):
        self.i2c.writeto(self.addr, b"\x40" + buf)

# =====================================================
# CONFIG
# =====================================================
I2C_SDA = 21
I2C_SCL = 22
OLED_ADDR = 0x3C

# Keypad 4x4 pins
ROW_PINS = [13, 12, 14, 27]   # R1..R4
COL_PINS = [26, 25, 33, 32]   # C1..C4

KEYMAP = [
    ['1','2','3','A'],
    ['4','5','6','B'],
    ['7','8','9','C'],
    ['*','0','#','D']
]

PASSWORD = "1234"
MAX_LEN = 8

# =====================================================
# INIT
# =====================================================
i2c = I2C(0, sda=Pin(I2C_SDA), scl=Pin(I2C_SCL), freq=400000)
oled = SSD1306_I2C(128, 64, i2c, addr=OLED_ADDR)

rows = [Pin(p, Pin.OUT) for p in ROW_PINS]
cols = [Pin(p, Pin.IN, Pin.PULL_UP) for p in COL_PINS]

# =====================================================
# KEYPAD scan
# =====================================================
def scan_key():
    # all rows HIGH
    for r in rows:
        r.value(1)

    for ri, r in enumerate(rows):
        r.value(0)
        time.sleep_us(200)  # stabilize
        for ci, c in enumerate(cols):
            if c.value() == 0:
                r.value(1)
                return KEYMAP[ri][ci]
        r.value(1)

    return None

def get_key():
    k = scan_key()
    if k is None:
        return None

    # debounce
    time.sleep_ms(40)
    if scan_key() != k:
        return None

    # wait release
    while scan_key() == k:
        time.sleep_ms(10)

    return k

# =====================================================
# UI
# =====================================================
def show_locked(buf, msg=""):
    oled.fill(0)
    oled.text("LOCKED", 40, 0)
    oled.text("Enter PIN:", 0, 20)
    oled.text("*" * len(buf), 0, 36)
    if msg:
        oled.text(msg[:16], 0, 54)
    oled.show()

def show_unlocked():
    oled.fill(0)
    oled.text("UNLOCKED", 28, 20)
    oled.text("A = lock", 32, 40)
    oled.show()

# =====================================================
# MAIN
# =====================================================
state = "LOCKED"
buf = ""
hint = ""

show_locked(buf)

while True:
    k = get_key()

    if state == "LOCKED":
        if k:
            if '0' <= k <= '9':
                if len(buf) < MAX_LEN:
                    buf += k
            elif k == '*':
                buf = buf[:-1]
            elif k == '#':
                if buf == PASSWORD:
                    state = "UNLOCKED"
                    buf = ""
                    show_unlocked()
                    time.sleep_ms(200)
                else:
                    buf = ""
                    hint = "Wrong PIN"
            elif k == 'A':
                buf = ""
                hint = "Cleared"

            if state == "LOCKED":
                show_locked(buf, hint)
                hint = ""

    else:  # UNLOCKED
        if k == 'A':
            state = "LOCKED"
            buf = ""
            hint = ""
            show_locked(buf)

    time.sleep_ms(30)
